package ejercicio.clase09.main;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import ejercicio.clase09.entities.*;

public class Main {

	public static void main(String[] args) {
		
		List<Vehiculo> lista = new ArrayList<Vehiculo>();
		
		lista.add(new Auto("Peugeot", "206", 4, 200000.00));
		lista.add(new Moto("Honda", "Titan", 125, 60000.00));
		lista.add(new Auto("Peugeot", "208", 5, 250000.00));
		lista.add(new Moto("Yamaha", "YBR", 160	, 80500.50));
		
		lista.forEach(System.out::println);
		
		System.out.println("\n=============================\n");
		
		Vehiculo vehiculo = lista.stream().max(Comparator.comparing(Vehiculo::getPrecio)).get();
		System.out.println("Vehículo más caro: "+vehiculo.getMarca()+" "+vehiculo.getModelo());
		
		vehiculo = lista.stream().min(Comparator.comparing(Vehiculo::getPrecio)).get();
		System.out.println("Vehículo más barato: "+vehiculo.getMarca()+" "+vehiculo.getModelo());
		
		lista.stream().filter(a->a.getModelo().contains("Y")).forEach(a->System.out.println("Vehículo que contiene en el modelo la letra ‘Y’: "+a.getMarca()+" "+a.getModelo()+" $"+a.getPrecioString()));

		System.out.println("\n=============================\n\nVehículos ordenados por precio de mayor a menor: ");
		lista.stream().sorted(Comparator.comparing(Vehiculo::getPrecio).reversed()).forEach(a->System.out.println(a.getMarca()+" "+a.getModelo()));
		
		Set<Vehiculo> set = new TreeSet<Vehiculo>();
		
		set.addAll(lista);
		
		System.out.println("\n=============================\n\nVehículos ordenados por orden natural:");
		set.forEach(System.out::println);
		

		
	}

	
}
