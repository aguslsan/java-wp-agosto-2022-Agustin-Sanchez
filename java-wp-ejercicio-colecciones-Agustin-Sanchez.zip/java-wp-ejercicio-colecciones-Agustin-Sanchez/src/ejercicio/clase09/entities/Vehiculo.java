package ejercicio.clase09.entities;

import java.text.DecimalFormat;

public abstract class Vehiculo implements Comparable<Vehiculo>{
	
	protected String marca;
	protected String modelo;
	protected Double precio;
	DecimalFormat df = new DecimalFormat();
	
	public Vehiculo(String marca, String modelo, Double precio) {
		this.marca = marca;
		this.modelo = modelo;
		this.precio = precio;
		
		df.setGroupingSize(3);
		df.setMaximumFractionDigits(2);
		df.setMinimumFractionDigits(2);
	}
	
	public int hashCode() {
		return toString().hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if (obj == null) return false;
		return this.hashCode()==obj.hashCode();
		
	}
	
	public int compareTo(Vehiculo para) { //como se agrega numeros para comparar?
		
		String thisVehiculo = this.getMarca()+","+this.getModelo()+","+this.getPrecio();
		String paraVehiculo = para.getMarca()+","+para.getModelo()+","+para.getPrecio();
		return thisVehiculo.compareTo(paraVehiculo);
		
	}
	
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public Double getPrecio() {
		return precio;
	}
	public String getPrecioString() {
		return df.format(precio);
	}
	public void setPrecio(Double precio) {
		this.precio = precio;
	}

}
