package ejercicio.clase09.entities;

public class Moto extends Vehiculo{

	private Integer cilindrada;
	
	public Moto(String marca, String modelo, Integer cilindrada, Double precio) {
		super(marca, modelo, precio);
		this.cilindrada = cilindrada;
	}

	@Override
	public String toString() {
		return "Marca: " + marca + " // Modelo: " + modelo + " // Cilindrada: " + cilindrada + "c // Precio: $" + this.getPrecioString();
	}
	
	public Integer getCilindrada() {
		return cilindrada;
	}

	public void setCilindrada(Integer cilindrada) {
		this.cilindrada = cilindrada;
	}

}
