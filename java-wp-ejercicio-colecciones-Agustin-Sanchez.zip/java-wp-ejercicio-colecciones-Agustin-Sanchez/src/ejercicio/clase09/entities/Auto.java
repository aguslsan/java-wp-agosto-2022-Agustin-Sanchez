package ejercicio.clase09.entities;

public class Auto extends Vehiculo{

	private Integer puertas;

	public Auto(String marca, String modelo, Integer puertas, Double precio) {
		super(marca, modelo, precio);
		this.puertas = puertas;
	}
	
	@Override
	public String toString() {
		return "Marca: " + marca + " // Modelo: " + modelo + " // Puertas: " + puertas + " // Precio: $" + this.getPrecioString();
	}
	
	public Integer getPuertas() {
		return puertas;
	}

	public void setPuertas(Integer puertas) {
		this.puertas = puertas;
	}
	

}
